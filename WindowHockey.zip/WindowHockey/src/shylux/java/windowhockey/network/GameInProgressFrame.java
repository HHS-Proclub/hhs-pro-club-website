package shylux.java.windowhockey.network;

import java.io.Serializable;

@SuppressWarnings("serial")
public class GameInProgressFrame implements Serializable {

}
