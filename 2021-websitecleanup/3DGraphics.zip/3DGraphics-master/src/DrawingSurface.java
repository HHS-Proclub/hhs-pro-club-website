import java.util.*;
import java.awt.*;
import processing.core.*;
import processing.event.*;

public class DrawingSurface extends PApplet {
	//ArrayList of keys - stores all currently pressed keys
	private ArrayList<Integer> keys;
	
	//Boolean to test if the mouse is currently clicked down
	private boolean clicked;
	
	//The current rotation in the x and the y direction
	private float x, y;
	
	//The rate/speed that the cube rotates at
	private float rate = .015f;
	
	//Colors used for the cube
	private Color nonVisible = Color.darkGray.brighter();
	private Color red = Color.red.darker();
	private Color blue = Color.blue.brighter();
	private Color green = Color.green.darker();
	private Color yellow = Color.yellow.darker();
	private Color orange = Color.orange.darker();
	private Color white = Color.white;

	public DrawingSurface() {
		keys = new ArrayList<Integer>();
	}

	public static void main(String[] args) {
		PApplet.main("DrawingSurface");
	}

	public void settings() {
		size(500, 500, P3D);
	}

	public void draw() {
		//Clears canvas
		clear();
		background(128);

		//Local variables
		float xLoc = width / 6f; //The x location of the center point
		float yLoc = height / 6f; //The y location of the center point
		float zLoc = 0; //The z location of the center point
		translate(xLoc*3, yLoc*4, zLoc); //Shifting the camera by these values
		
		
	}

	//Adds the key pressed to the ArrayList.
	public void keyPressed() {
		keys.add(keyCode);
	}

	//Removes the keys that are no longer pressed from the ArrayList.
	public void keyReleased() {
		while (checkKey(keyCode))
			keys.remove(new Integer(keyCode));
	}

	private boolean checkKey(int i) {
		return keys.contains(i);
	}

	public void mousePressed() {
		clicked = true;
	}

	public void mouseDragged() {
		
	}

	public void mouseWheel(MouseEvent e) {

	}

	public void mouseReleased() {
		clicked = false;
	}

	//Color Params in order: front of cube, back, bottom, top, right, left
	public void multiColoredBox(Color f1, Color f2, Color f3, Color f4, Color f5, Color f6, float x, float y, float z) {
		
	}

}
