import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;

public class GamePanel extends JPanel implements KeyListener, ActionListener {
	
	boolean areObstacles=false;
	
	Mario mario;
	ArrayList<Rectangle> obstacles;
	
	javax.swing.Timer clock;
	boolean rightKey, leftKey, debugMode;
	
	int width, height;
	
	public GamePanel () {
		super();
		setFocusable(true);
		mario = new Mario("mario.png", 300, 100, 80, 100, false);
		obstacles = new ArrayList<Rectangle>();
		obstacles.add(new Rectangle(0, 600, 440, 1000));
		addKeyListener(this);
		clock = new javax.swing.Timer(1000 / mario.getFps(), this);
		clock.start();
		debugMode = mario.isDebugMode();
	}

	/**
	 * Runs continuously to animate the game
	 */
	public void paintComponent(Graphics g) {
		super.paintComponent(g);  // Call JPanel's paintComponent method to paint the background

		Graphics2D g2 = (Graphics2D)g;

		width = getWidth();
		height = getHeight();

		if (areObstacles) {
			obstacles.add(new Rectangle(400, 300, 120, 120));
		}

		if (debugMode) {
			g2.drawString("MarioX: " + mario.getX(), 10, 15);
			g2.drawString("MarioY: " + mario.getY(), 10, 30);
			g2.drawString("Is Mario on the Ground? " + mario.isOnGround(), 10, 45);
			g2.drawString("Mario's Downward Velocity: " + mario.getyV(), 10, 60);
			g2.drawString("Mario's jumpForce: " + mario.getJumpForce(), 10, 75);
			g2.drawString("Mario's gravity: " + mario.getGravity(), 10, 90);
			g2.drawString("Mario's stepSize: " + mario.getStepSize(), 10, 105);
			g2.drawString("Mario's fps: " + mario.getFps(), 10, 120);
			g2.drawString("Paused? " + mario.isPause(), 10, 150);
			g2.drawString("Airtime(In Frames): " + mario.getAirtime(), 10, 135);
		}

		for (Shape s : obstacles) {
			g2.fill(s);
		}

		mario.draw(g2,this,width,height);

		// TODO Add any custom drawings here
	}

	/**
	 * Runs once when a key is pressed down.
	 * 
	 * e.getKeyCode() returns the ID of the key pressed and corresponds to the
	 * KeyEvent.VK_* constants
	 */
	public void keyPressed(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_LEFT) {
			rightKey = false;
			leftKey = true;
		} else if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
			leftKey = false;
			rightKey = true;
		} else if (e.getKeyCode() == KeyEvent.VK_UP) {
			mario.jump();
		} else if (e.getKeyCode() == KeyEvent.VK_P || e.getKeyCode() == KeyEvent.VK_ENTER) {
			mario.togglePause();
		}
	}

	/**
	 * Runs when a key is released
	 * 
	 * e.getKeyCode() returns the ID of the key pressed and corresponds to the
	 * KeyEvent.VK_* constants
	 */
	public void keyReleased(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_LEFT) {
			leftKey = false;
		} else if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
			rightKey = false;
		} else if (e.getKeyCode() == KeyEvent.VK_UP) {
			mario.jump();
		}
	}

	public void keyTyped(KeyEvent e) {
		
	}

	/**
	 * Runs any time a key is pressed or released
	 */
	public void actionPerformed(ActionEvent e) {
		if (leftKey) {
			mario.walk(-1);
		}
		if (rightKey) {
			mario.walk(1);
		}

		mario.act(obstacles, width, height);
		repaint();
	}

}
