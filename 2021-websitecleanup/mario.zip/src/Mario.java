/**
 * This class represents an Image that can easily be moved around the screen.
 * 
 * This image can be either scalable or non-scalable, depending on how the
 * programmer sets the resizable field.
 * 
 * In short:
 *  * If the resizable field is set to false, all coordinates used
 *    (including arguments passed in) are pixel coordinates.
 *  * If the resizable field is set to true, all coordinates used
 *    (including arguments passed in) are decimal numbers between 0 and 1,
 *    representing percentages of the screen. In this system, an x coordinate
 *    of 0.5 would indicate that the image should be drawn half way across
 *    the width of the window.
 * 
 * Author: Shelby
 * Date: 4/26/11
 */

import java.awt.*;
import javax.swing.*;
import java.awt.image.*;
import java.util.*;

public class Mario {
	
	// FIELDS: Edit these to change the physics of Mario
	
	/** whether the debug info is showing */
	private boolean debugMode = true;
	/** whether the time is paused */
	private boolean pause = false;
	/** whether mario is visible */
	private boolean isVisible=true;
	/** how strongly gravity is pulling mario down */
	private double gravity = 2.0;
	/** how much force is in mario's jump */
	private double jumpForce = 25.0;
	/** how many pixels mario moves in each act method/frame */
	private int stepSize = 8;
	/** how many frames per second the game runs at */
	private int fps = 40;
	
	// Changing these doesn't really do anything
	private Image img;
	private boolean resizable;
	private boolean onGround;
	private double xCoord, yCoord, width, height;
	private double yV = 0;
	private int airtime = 0;

	// CONSTRUCTOR
	
	/**
	 * If resizable==false, then x, y, width, height are all pixel coordinates
	 * on the screen, and this is not a scalable image (it is always in the
	 * same place and the same size).
	 * Example usage: sun = new MovingImage("sun.jpg", 360, 48, 120, 144, false);
	 *
	 * If resizable==true, then x, y, width, height are all decimal values
	 * between 0 and 1 representing a percentage of the way across the
	 * window, where 0 is 0% of the window and 1 is 100% of the window.
	 * This will allow for a resizable, scalable image.
	 * Example usage: sun = new MovingImage("sun.jpg", 6.0/10, 1.0/10, 1.0/5, 3.0/10, true);
	 */
	public Mario(String filename, double x, double y, double width, double height, boolean resizable) {
		img = (new ImageIcon(filename)).getImage();
		isVisible = true;
		xCoord = x;
		yCoord = y;
		this.width = width;
		this.height = height;
		this.resizable = resizable;
	}

	// METHODS
	
	/**
	 * MovingImage "jumps" to the location passed in as arguments.
	 */
	public void moveToLocation(int x, int y) {
		xCoord = x;
		yCoord = y;
	}

	/**
	 * MovingImage moves left/right or up/down by the amount passed
	 * in as arguments. Pass a negative number to move the other direction.
	 */
	public void moveByAmount(double x, double y) {
		if(!pause) {
			xCoord += x;
			yCoord += y;
			
			if (xCoord < 0) {
				xCoord = 0;
			}
			if (yCoord < 0) {
				yCoord = 0;
			}
			
			if (resizable) {
				if (xCoord > 1) {
					xCoord = 1;
				}
				if (yCoord > 1) {
					yCoord = 1;
				}
			}
		}
	}

	public double getX() {
		return xCoord;
	}

	public double getY() {
		return yCoord;
	}

	/**
	 * Draws Mario on the given canvas
	 * 
	 * If the MovingImage should be visible, draws the MovingImage to the
	 * screen in the way specified by the resizable field.
	 */
	public void draw(Graphics g, ImageObserver io, int windowWidth, int windowHeight) {
		if (!isVisible) {
			return;
		}
		
		if (resizable) {
			g.drawImage(img, (int)(xCoord*windowWidth), (int)(yCoord*windowHeight), (int)(width*windowWidth), (int)(height*windowHeight), io);
		} else {
			g.drawImage(img, (int)xCoord, (int)yCoord, (int)width, (int)height, io);
		}
	}

	/**
	 * Switches the MovingImage visibility to the opposite of what it is
	 * currently.
	 */
	public void swapVisibility() {
		isVisible = !isVisible;
	}

	/**
	 * Returns the visibility of the MovingImage.
	 */
	public boolean isVisible() {
		return isVisible;
	}

	/**
	 * Returns true if the x,y point passed in is inside of this image.
	 * (For example, to check and see if this image was clicked on)
	 */
	public boolean isPointInsideImage(double x, double y) {
		if (x >= xCoord && x <= xCoord + width && y >= yCoord && y <= yCoord + height) {
			return true;
		}
		return false;
	}

	/**
	 * Makes Mario walk either left or right. 
	 * if dir =
	 *   * -1	Mario walks left
	 *   * 1	Mario walks right
	 */
	public void walk(int dir) {
		moveByAmount(dir * stepSize, 0);
	}

	/**
	 * Makes Mario jump only if he is currently standing
	 */
	public void jump() {
		if (onGround) {
			yV = -jumpForce;
		}
	}

	public void act(ArrayList<Rectangle> obstacles, int screenWidth, int screenHeight) {
		onGround = false;
		
		if (pause) {
			return;
		}
		
		moveByAmount(0, (int) yV);
		if (onGround == false) {
			yV += gravity;
		} else {
			yV += 0;
		}
		
		if (xCoord + width > screenWidth) {
			xCoord = screenWidth - width - 1;
		}
		if (yCoord + height > screenHeight) {
			yCoord = screenHeight - height - 1;
		}
		
		for (Shape s : obstacles) {
			if (s.contains(xCoord, yCoord) || s.contains(xCoord + width, yCoord)){
				
				while(s.contains(xCoord, yCoord)||s.contains(xCoord + width, yCoord)){
					moveByAmount(0, 1);
				}
			}
			if (s.contains(xCoord, yCoord + height + 1) || s.contains(xCoord + width, yCoord + height + 1)) {
				
				while (s.contains(xCoord, yCoord + height) || s.contains(xCoord + width, yCoord + height)) {
					moveByAmount(0, -1);
				}
				
				onGround = true;
				yV = 0;
				airtime = 0;
			}
			
		}
		if (!onGround) {
			airtime += 1;
		}
	}
	
	public int getAirtime() {
		return airtime;
	}

	public void setAirtime(int airtime) {
		this.airtime = airtime;
	}

	public void togglePause() {
		pause = !pause;
	}

	public boolean isOnGround() {
		return onGround;
	}

	public void setOnGround(boolean onGround) {
		this.onGround = onGround;
	}

	public double getGravity() {
		return gravity;
	}

	public void setGravity(int gravity) {
		this.gravity = gravity;
	}

	public double getyV() {
		return yV;
	}

	public void setyV(int yV) {
		this.yV = yV;
	}

	public double getJumpForce() {
		return jumpForce;
	}

	public void setJumpForce(int jumpForce) {
		this.jumpForce = jumpForce;
	}
	
	public int getFps() {
		return fps;
	}

	public void setFps(int fps) {
		this.fps = fps;
	}

	public int getStepSize() {
		return stepSize;
	}

	public void setStepSize(int stepSize) {
		this.stepSize = stepSize;
	}
	
	public boolean isDebugMode() {
		return debugMode;
	}

	public void setDebugMode(boolean debugMode) {
		this.debugMode = debugMode;
	}
	
	public boolean isPause() {
		return pause;
	}

	public void setPause(boolean pause) {
		this.pause = pause;
	}

}
