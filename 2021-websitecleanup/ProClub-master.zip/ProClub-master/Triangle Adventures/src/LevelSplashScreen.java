import javax.swing.JPanel;


public class LevelSplashScreen extends JPanel {

}
