package rfeng;

import processing.core.PApplet;

public class PhysicsEntity
{
	public static final double GRAVITY = 0.05;
	private double x, y, vx, vy;
	
	public PhysicsEntity(double x, double y, double vx, double vy)
	{
		this.x=x;
		this.y=y;
		this.vx=vx;
		this.vy=vy;
	}
	
	public void draw(PApplet drawer)
	{
		//draw something here at location (x,y)
	}
	
	public void act()
	{
		/*
		 * In this area, move the entity based on the velocities in the x and y direction.
		 * Hint: x changes by vx, y changes by vy
		 */
		//implement here
		
		//bound x and y between max and min
		x = bound(x, 0, 400);
		y = bound(y, 0, 300);
		
		/*
		 * Every frame, we want to change vy by GRAVITY, essentially giving it downward
		 * acceleration.
		 */
		//add GRAVITY to vy on this line
		
		if(y == 300) vy = 0;
	}
	
	private double bound(double var, double min, double max)
	{
		return Math.max(min, Math.min(var, max));
	}
	
	public void addVX(double add)
	{
		vx+=add;
	}
	
	/*
	 * Make this entity jump up by setting y velocity to some negative value.
	 * Remember that negative y direction is up, so giving negative y velocity
	 * will cause the entity to jump up.
	 */
	public void jump()
	{
		//implement here
	}
	
	public boolean isGrounded()
	{
		return y == 300;
	}
}
