package rfeng;

import java.awt.event.KeyEvent;

import processing.core.PApplet;


public class DrawingSurface extends PApplet
{
	private PhysicsEntity entity;
	private boolean left, right;
	
	public DrawingSurface()
	{
		entity = new PhysicsEntity(200, 150, 0, 0);
		left = false;
		right = false;
	}

	public void draw()
	{ 
		background(255);
		scale(width/400f, height/300f);
		
		entity.draw(this);
		entity.act();
	}
	
	public void keyPressed()
	{
		if(keyCode == KeyEvent.VK_LEFT && !left)
		{
			left = true;
			entity.addVX(-2);
		}
		else if(keyCode == KeyEvent.VK_RIGHT && !right)
		{
			right = true;
			entity.addVX(2);
		}
		else if(keyCode == KeyEvent.VK_UP && entity.isGrounded())
		{
			entity.jump();
		}
	}
	
	public void keyReleased()
	{
		if(keyCode == KeyEvent.VK_LEFT)
		{
			left = false;
			entity.addVX(2);
		}
		else if(keyCode == KeyEvent.VK_RIGHT)
		{
			right = false;
			entity.addVX(-2);
		}
	}
}
