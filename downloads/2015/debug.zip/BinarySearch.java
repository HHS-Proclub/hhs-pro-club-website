import java.util.*;

public class BinarySearch {
	public static void main(String[] args) {
		Scanner read = new Scanner(System.in);
		int numberOfWords = Integer.parseInt(read.nextLine());
		String words[] = new String[numberOfWords];
		for(int i = 0; i < numberOfWords; i++)
			words[i] = read.nextLine();
		Arrays.sort(words);
		String searchWord = read.nextLine();  
		int index = binarySearch(words, 0, numberOfWords - 1, searchWord);
		
		System.out.println(searchWord + " found at index " + index);
	}
	
	public static int binarySearch(String[] words, int begin, int end, String searchWord) 
	{
		if(end < begin) //searched through everything
		{
			return -1;
		}

		int mid = (begin + end) / 2; //"middle" index

		if(searchWord.compareTo(words[mid]) == 0) 
			return mid; //Found word
		else if(searchWord.compareTo(words[mid]) == -1) //word is lower than mid
			return binarySearch(words, begin, mid, searchWord);
		else if(searchWord.compareTo(words[mid]) == 1) //word is higher than mid
			return binarySearch(words, mid, end, searchWord);
		
		return -1;
	}

}