
public class ForLoops {
	public static void main(String[] args){
		int number = 1;
		for(int i = 1; i < 10; i++){
			System.out.println(number);
			number++;
		}
	}
}
