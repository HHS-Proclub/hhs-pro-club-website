import java.io.*;
import java.util.*;

public class Pyramids {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int numLevels = Integer.parseInt(in.nextLine());
		for (int i=0; i<numLevels; i++) {
			for (int j=0; j<i; j++) {
				System.out.print('*');
			}
			System.out.println();
		}
	}
}
