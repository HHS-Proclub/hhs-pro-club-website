
public class Block extends MovingImage {

	public Block(int x, int y) {
		super("block.png", x, y, 100, 100);
	}
	
}
