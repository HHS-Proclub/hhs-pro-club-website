public class Levels {
	public static final Level[] levels = new Level[] {
			new Level1(),
			new Level2(),
			new Level3(),
			new Level4(),
			new Level5(),
			new Level6(),
			new Level7(),
			new Level8(),
			new Level9(),
			new Level10(),
			new Level11(),
			new Level12(),
			new Level13(),
			new Level14(),
			new Level15(),
			new Level16()
	};
	
	public static final SplashScreen[] levelSplashScreens = new SplashScreen[] {
			new Level1Panel(),
			new Level2Panel(),
			new Level3Panel(),
			new Level4Panel(),
			new Level5Panel(),
			new Level6Panel(),
			new Level7Panel(),
			new Level8Panel(),
			new Level9Panel(),
			new Level10Panel(),
			new Level11Panel(),
			new Level12Panel(),
			new Level13Panel(),
			new Level14Panel(),
			new Level15Panel()//,
			//new Level16Panel()
	};

}
