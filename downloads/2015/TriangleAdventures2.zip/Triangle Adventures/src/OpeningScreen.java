import javax.swing.JPanel;


public class OpeningScreen extends JPanel {

}
