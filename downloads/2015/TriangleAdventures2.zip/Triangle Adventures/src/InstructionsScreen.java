import javax.swing.JPanel;


public class InstructionsScreen extends JPanel {

}
