import java.io.*;
import java.util.*;
import java.lang.*;

public class BalancePendulum {

	public static final String ACTIONS_FILE = "actions.txt";
	public static final String RESULTS_FILE = "results.txt";

	public static final String SIMULATION_EXECUTABLE = "java -jar pendulum.jar";

	public static final int MIN_ANGLE = 0;
	public static final int CORRECT_ANGLE = 90;
	public static final int MAX_ANGLE = 180;

	public static final int MAX_ANGULAR_SPEED = 30;
	public static final int CORRECT_ANGULAR_SPEED = 0;
	public static final int MIN_ANGULAR_SPEED = -30;

	public static final int NUM_SIMULATIONS = 10;

	/*
	 * Do NOT edit the above constants. Otherwise, the program will likely not
	 * work.
	 */

	
	/**
	 * Produces an actions file.
	 */
	private static void generateActions(String fileName) throws IOException, InterruptedException {
		PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(fileName)));
		
		
		/***********************************************************************
		 * You will need to modify the logic here to make the behavior smarter.
		 **********************************************************************/
		for (int angle = MIN_ANGLE; angle <= MAX_ANGLE; angle++) {
			for (int angularSpeed = MIN_ANGULAR_SPEED; angularSpeed <= MAX_ANGULAR_SPEED; angularSpeed++) {
				if (angle <= 90) {

					
					out.println(angle + " " + angularSpeed + " L");
				}
				else {
					out.println(angle + " " + angularSpeed + " R");
				}
			}
		}
		out.flush();
		out.close();
	}
	
	
	
	public static void main(String[] args) throws IOException, InterruptedException {
		generateActions(ACTIONS_FILE);
		runSimulation(true);
		System.out.println("Score: " + readScore());
	}

	private static double readScore() throws IOException {
		BufferedReader br = new BufferedReader(new FileReader("score.txt"));
		String s = br.readLine();
		br.close();
		return Double.parseDouble(s);
	}


	/**
	 * Runs the provided simulation, and returns the statistics. You should not
	 * need to modify this function.
	 */
	private static List<String> runSimulation(boolean visualization) throws IOException, InterruptedException {
		/* Run the simulation. */
		String simulation = SIMULATION_EXECUTABLE;
		if (!visualization)
			simulation += " " + NUM_SIMULATIONS;
		Process p = Runtime.getRuntime().exec(simulation);

		int exitCode = p.waitFor();
		// System.out.println("Exit code: " + exitCode);

		if (exitCode != 0) {
			System.out.println("There is an error in the starter code. Please alert a ProCo staff member.");
			return null;
		}

		/* Parse the results from the output file. */
		List<String> results = new ArrayList<String>();
		BufferedReader br = new BufferedReader(new FileReader(RESULTS_FILE));
		String s;
		while ((s = br.readLine()) != null) {
			results.add(s);
		}
		return results;
	}

}
