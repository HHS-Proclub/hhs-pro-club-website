/**
 * Edit this file to play Triangle Adventures! 
 *
 */

public class TriangleAdventures {

	// Change the level by changing the number below
	public static final int LEVEL_NUMBER = 13;
	
	// Set to true to run all 16 levels and check for completion
	public static final boolean LEVEL_CHECKER = true;
	
	// Player commands for Level 1
	public static void solveLevel1(Player player) {
		player.move();
	}

	// Player commands for Level 2
	public static void solveLevel2(Player player) {
		player.move();
	}

	// Player commands for Level 3
	public static void solveLevel3(Player player) {
		player.move();
	}

	// Player commands for Level 4
	public static void solveLevel4(Player player) {
		player.move();
	}

	// Player commands for Level 5
	public static void solveLevel5(Player player) {
		player.move();
	}

	// Player commands for Level 6
	public static void solveLevel6(Player player) {
		player.move();
	}

	// Player commands for Level 7
	public static void solveLevel7(Player player) {
		player.move();
	}

	// Player commands for Level 8
	public static void solveLevel8(Player player) {
		player.move();
	}

	// Player commands for Level 9
	public static void solveLevel9(Player player) {
		player.move();
	}

	// Player commands for Level 10
	public static void solveLevel10(Player player) {
		player.move();
	}

	// Player commands for Level 11
	public static void solveLevel11(Player player) {
		player.move();
	}

	// Player commands for Level 12
	public static void solveLevel12(Player player) {
		player.move();
	}

	// Player commands for Level 13
	public static void solveLevel13(Player player) {
		player.move();
	}

	// Player commands for Level 14
	public static void solveLevel14(Player player) {
		player.move();
	}

	// Player commands for Level 15
	public static void solveLevel15(Player player) {
		player.move();
	}

	// Player commands for Level 16
	public static void solveLevel16(Player player) {
		player.move();
	}

	// Run game
	public static void main(String[] args) {
		final Main game = new Main();
		game.run();
	}

}
