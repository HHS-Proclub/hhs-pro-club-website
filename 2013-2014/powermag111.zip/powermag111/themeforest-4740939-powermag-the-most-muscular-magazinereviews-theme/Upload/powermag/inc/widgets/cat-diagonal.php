<span class="cat-diagonal" style="
			
				background: -moz-linear-gradient(-45deg,  <?php echo $category_color ?> 0%, <?php echo $category_color ?> 50%, rgba(0,0,0,0) 51%, rgba(0,0,0,0) 100%);
				background: -webkit-gradient(linear, left top, right bottom, color-stop(0%,<?php echo $category_color ?>), color-stop(50%,<?php echo $category_color ?>), color-stop(51%,rgba(0,0,0,0)), color-stop(100%,rgba(0,0,0,0)));
				background: -webkit-linear-gradient(-45deg,  <?php echo $category_color ?> 0%,<?php echo $category_color ?> 50%,rgba(0,0,0,0) 51%,rgba(0,0,0,0) 100%);
				background: -o-linear-gradient(-45deg,  <?php echo $category_color ?> 0%,<?php echo $category_color ?> 50%,rgba(0,0,0,0) 51%,rgba(0,0,0,0) 100%); 
				background: -ms-linear-gradient(-45deg,  <?php echo $category_color ?> 0%,<?php echo $category_color ?> 50%,rgba(0,0,0,0) 51%,rgba(0,0,0,0) 100%); 
				background: linear-gradient(135deg,  <?php echo $category_color ?> 0%,<?php echo $category_color ?> 50%,rgba(0,0,0,0) 51%,rgba(0,0,0,0) 100%);			
			"></span>