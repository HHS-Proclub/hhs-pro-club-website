<span class="cat-angle" style="
			background: -moz-linear-gradient(-45deg,  rgba(0,0,0,0) 0%, rgba(0,0,0,0) 50%, <?php echo $category_color ?> 51%, <?php echo $category_color ?> 83%, <?php echo $category_color ?> 100%); /* FF3.6+ */
			background: -webkit-gradient(linear, left top, right bottom, color-stop(0%,rgba(0,0,0,0)), color-stop(50%,rgba(0,0,0,0)), color-stop(51%,<?php echo $category_color ?>), color-stop(83%,<?php echo $category_color ?>), color-stop(100%,<?php echo $category_color ?>)); /* Chrome,Safari4+ */
			background: -webkit-linear-gradient(-45deg,  rgba(0,0,0,0) 0%,rgba(0,0,0,0) 50%,<?php echo $category_color ?> 51%,<?php echo $category_color ?> 83%,<?php echo $category_color ?> 100%); /* Chrome10+,Safari5.1+ */
			background: -o-linear-gradient(-45deg,  rgba(0,0,0,0) 0%,rgba(0,0,0,0) 50%,<?php echo $category_color ?> 51%,<?php echo $category_color ?> 83%,<?php echo $category_color ?>) 100%); /* Opera 11.10+ */
			background: linear-gradient(135deg,  rgba(0,0,0,0) 0%,rgba(0,0,0,0) 50%,<?php echo $category_color ?> 51%,<?php echo $category_color ?> 83%,<?php echo $category_color ?> 100%); /* W3C */
			">
			</span>
