import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;

import org.json.JSONArray;
import org.json.JSONObject;

public class Main {

	public static void main(String[] args) {
		// get all leaderboard data
		String data = getJSON("http://hhsprogramming.com/leaderboard?data");
		JSONArray arr = new JSONArray(data);
		for (int i = 0; i < arr.length(); i++) {
			System.out.println(arr.getJSONObject(i).get("name") + " - " + arr.getJSONObject(i).get("points"));
		}
		System.out.println();
		
		// get leaderboard data for a single person
		data = getJSON("http://hhsprogramming.com/leaderboard?data&name=Soham%20Pardeshi");
		JSONObject jsonData = new JSONObject(data);
		System.out.println(jsonData.get("name"));
		System.out.println(jsonData.get("points"));
		System.out.println();
		
		// get song data from Spotify
		data = getJSON("https://api.spotify.com/v1/search?q=native&type=album&limit=1");
		jsonData = new JSONObject(data);
		System.out.println(jsonData.getJSONObject("albums").getJSONArray("items").getJSONObject(0)
				.getJSONArray("images").getJSONObject(0).get("url"));
		
	}
	
	public static String getJSON(String urlOfData) {
		try {
			URL url = new URL(urlOfData);
			URLConnection con = url.openConnection();
			InputStream ins = con.getInputStream();
			BufferedReader br = new BufferedReader(new InputStreamReader(ins));
			String data = "";
			String line;
			while ((line = br.readLine()) != null)
				data += line;
			return data;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "";
	}

}
