public class Main {

	public static void main(String[] args) {
		Sound s = new Sound();
		
		////////////////////////////////////
		// call Sound methods on s below
		////////////////////////////////////
		
		// Example:
		// s.add("sample.wav");
		// s.play();
		
		s.add("sample.wav");
		s.setSpeed(18);
		s.play();
		s.play();
	}

}
