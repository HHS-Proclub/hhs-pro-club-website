import javax.swing.JPanel;


public class SuccessScreen extends JPanel {

}
