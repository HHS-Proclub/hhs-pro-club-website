

public interface Level {

	public void load(World world, Player player);

}
