
public class LinearRegressionModel {
	
	double[][] x; // input
	double[] y; // output
	double[] weights; // theta
	double learningRate; // alpha
	
	// Initializes model with training data and learningRate
	public LinearRegressionModel(double[][] xData, double[] yData, double r) {
		
	}
	
	// Returns the root mean squared error of yPredict vs yReal
	public double getRMSE(double[] yPredict, double[] yReal) {
		return 0;
	}
	
	// Returns array of predictions for inputted xData
	public double[] getPrediction(double[][] xData) {
		return null;
	}
	
	// Batch Gradient Descent for n iterations
	public void gradientDescent(int n) {
		
	}
}
