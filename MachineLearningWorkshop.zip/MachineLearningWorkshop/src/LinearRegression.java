import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class LinearRegression {
	
	public static void main(String[] args) {
		
		int instances = 400, features = 13;
		double[][] xData = new double[instances][features];
		double[] yData = new double[instances];
		
		// Read data from the Boston Housing file
		
		
		// Normalize xData
		
		
		// Normalize yData
		
		
		// Split data into training, testing

		
		// Create Model w/ training data & learning rate (alpha)
		

		// Iterate batch gradient descent

		
		// Results after training
		
	}

}
